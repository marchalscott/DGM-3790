Difference in my code

I added a Nuke Attack button
	- This make the user win but should only be used in the most extreme circumstances.

I added a Magic Elixir button
	- The function of this button is to give 50 health unless the user is more the 50 health total. If the user is more than 50 health total then the elixir will decrease the health of the user by 50.

I added a Random button
	- This button hits both the monster and the user a random amount.

I added styling for the new buttons

I didnt have my code refactored but I decided to refactor it because it looked a lot better and a lot more simple.

